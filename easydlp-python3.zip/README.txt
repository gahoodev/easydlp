EASY-DLP

This archive contains:
- eazydlp.py
- requirements.txt
- README.txt
- run.bat (Windows launcher)

Usage:
- Install dependencies: pip install -r requirements.txt
- Run: python eazydlp.py

This text file is intended for inclusion inside the ZIP distribution.
