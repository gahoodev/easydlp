EASY-DLP

This archive contains:
- easydlp.py
- requirements.txt
- README.txt
- run.bat (Windows launcher)

Usage:
- Install dependencies: pip install -r requirements.txt
- Run: python easydlp.py

This text file is intended for inclusion inside the ZIP distribution.
