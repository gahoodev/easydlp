import subprocess
import re
import json
import sys
import os
from datetime import datetime
from pathlib import Path
from colorama import Fore, init
from colorist import ColorHex as h

init(autoreset=True)

# --- Configuration ---
YTDLP_CMD = "yt-dlp"

# Get Downloads folder path
def get_downloads_folder():
    """Get the user's Downloads folder path."""
    if sys.platform == 'win32':
        # Windows
        downloads_path = str(Path.home() / "Downloads")
    elif sys.platform == 'darwin':
        # macOS
        downloads_path = str(Path.home() / "Downloads")
    else:
        # Linux
        downloads_path = str(Path.home() / "Downloads")
    return downloads_path

DEFAULT_SAVE_DIR = get_downloads_folder()  # Default save directory (Downloads folder)

# Color palette
COLORS = {
    "green": h("#65fb07"),
    "red": h("#Fb0707"),
    "yellow": h("#FFCD00"),
    "blue": h("#00aaff"),
    "cyan": h("#EE82EE"),
    "magenta": h("#b207f5"),
    "light_blue": h("#EE82EE"),
    "white": h("#DCDCDC"),
    "gray": h("#8a837e"),
    "pink": h("#c203fc"),
    "arrow": h("#07f0ec"),
}

def get_terminal_width():
    """Get terminal width, default to 80 if not available."""
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 80

def clear_screen():
    """Clear the screen in a cross-platform way."""
    try:
        os.system("cls" if os.name == "nt" else "clear")
    except Exception:
        pass

def render_ascii():
    """Render the EASY-DLP ASCII art header."""
    clear_screen()
    width = get_terminal_width()
    
    edges = ["╗", "║", "╚", "╝", "═", "╔", "─", "╭", "╮", "┌", "┐", "└", "┘"]
    
    ascii_art = f"""
{'███████╗ █████╗ ███████╗██╗   ██╗     ██████╗ ██╗     ██████╗ '.center(width)}
{'██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝     ██╔══██╗██║     ██╔══██╗'.center(width)}
{'█████╗  ███████║███████╗ ╚████╔╝█████╗██║  ██║██║     ██████╔╝'.center(width)}
{'██╔══╝  ██╔══██║╚════██║  ╚██╔╝ ╚════╝██║  ██║██║     ██╔═══╝ '.center(width)}
{'███████╗██║  ██║███████║   ██║        ██████╔╝███████╗██║     '.center(width)}
{'╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝        ╚═════╝ ╚══════╝╚═╝     '.center(width)}
"""
    
    for line in ascii_art.splitlines():
        for edge in edges:
            line = line.replace(edge, f"{COLORS['light_blue']}{edge}{COLORS['white']}")
        print(line)

def log_message(status="Info", color="blue", message="", details=""):
    """Log a formatted message with timestamp."""
    timestamp = datetime.now().strftime(f'{Fore.LIGHTBLACK_EX}%H:%M:%S{Fore.RESET}')
    response = f"{Fore.RESET}[{timestamp}] "
    
    if status:
        response += f"[{COLORS[color]}{status}{COLORS['white']}] "
    
    if message:
        response += f"{message}"
    
    if details:
        response += f" ({COLORS['gray']}{details}{COLORS['white']})"
    
    print(response)

def get_formats(url):
    """
    Runs yt-dlp to get available formats and parses the JSON output.
    Returns a list of format dictionaries.
    """
    log_message("Fetch", "cyan", "Fetching available formats... This may take a moment.")
    try:
        result = subprocess.run(
            [YTDLP_CMD, url, "--dump-json", "--no-warnings", "--no-call-home", "--skip-download"],
            capture_output=True,
            text=True,
            check=True
        )
        info = json.loads(result.stdout)
        
        if 'formats' not in info:
            log_message("Error", "red", "Could not find format information for this URL.")
            return None
            
        best_format = {
            'format_id': 'BEST',
            'ext': 'Auto',
            'resolution': 'Best Quality (Auto-Merge)',
            'vcodec': 'Auto',
            'acodec': 'Auto',
            'note': 'bestvideo+bestaudio/best'
        }
        
        processed_formats = [best_format]
        for f in info['formats']:
            if f.get('ext') and f.get('format_id') and f.get('vcodec', 'none') != 'none' and f.get('acodec', 'none') != 'none':
                res = f.get('resolution', 'N/A')
                vcodec = f.get('vcodec', 'N/A')
                acodec = f.get('acodec', 'N/A')
                note = 'Video+Audio'
            elif f.get('vcodec', 'none') != 'none' and f.get('acodec', 'none') == 'none':
                res = f.get('resolution', 'N/A')
                vcodec = f.get('vcodec', 'N/A')
                acodec = 'none'
                note = 'Video Only'
            elif f.get('vcodec', 'none') == 'none' and f.get('acodec', 'none') != 'none':
                res = 'N/A'
                vcodec = 'none'
                acodec = f.get('acodec', 'N/A')
                note = 'Audio Only'
            else:
                continue

            processed_formats.append({
                'format_id': f['format_id'],
                'ext': f['ext'],
                'resolution': res,
                'vcodec': vcodec,
                'acodec': acodec,
                'note': note
            })
            
        log_message("Success", "green", f"Found {len(processed_formats) - 1} formats")
        return processed_formats
        
    except subprocess.CalledProcessError as e:
        log_message("Error", "red", f"Error running {YTDLP_CMD}", e.stderr[:50])
        return None
    except FileNotFoundError:
        log_message("Error", "red", f"{YTDLP_CMD} command not found. Please ensure it's installed.")
        return None
    except json.JSONDecodeError:
        log_message("Error", "red", "Could not parse JSON output from yt-dlp.")
        return None
    except Exception as e:
        log_message("Error", "red", f"An unexpected error occurred: {str(e)[:50]}")
        return None

def select_format(formats, media_type='mp4'):
    """
    Displays the formats in a table and prompts the user for selection.
    
    Args:
        formats: List of available formats
        media_type: 'mp4' or 'mp3' - filters out audio-only for mp4
    """
    if not formats:
        return None

    width = get_terminal_width()
    
    # Filter formats based on media type
    if media_type == 'mp4':
        # For MP4, exclude Audio Only formats
        filtered_formats = [f for f in formats if f.get('note') != 'Audio Only']
    else:
        filtered_formats = formats
    
    if not filtered_formats:
        log_message("Error", "red", "No suitable formats available for this media type")
        return None
    
    # Draw header
    print(f"\n{COLORS['light_blue']}{'╭─ Available Formats '.ljust(width-4, '─')}╮{COLORS['white']}")
    
    # Column headers with alignment
    header = f"{'No.':<4} {'Format ID':<12} {'Resolution':<16} {'Ext':<6} {'VCodec':<10} {'ACodec':<10} {'Note':<18}"
    print(f"{COLORS['cyan']}{header}{COLORS['white']}")
    print(f"{COLORS['light_blue']}{('─' * (width - 4))}{COLORS['white']}")
    
    id_map = {}
    
    for i, f in enumerate(filtered_formats):
        display_num = str(i)
        
        if f['format_id'] == 'BEST':
            display_num = '0'
            id_map[display_num] = f['note']
            display_row = f"{COLORS['green']}{display_num:<4}{COLORS['white']} {f['format_id']:<12} {f['resolution']:<16} {f['ext']:<6} {f['vcodec']:<10} {f['acodec']:<10} {COLORS['green']}{f['note']:<18}{COLORS['white']}"
        else:
            id_map[display_num] = f['format_id']
            display_row = f"{display_num:<4} {f['format_id']:<12} {f['resolution']:<16} {f['ext']:<6} {f['vcodec']:<10} {f['acodec']:<10} {f['note']:<18}"
        
        print(display_row)
    
    print(f"{COLORS['light_blue']}{('─' * (width - 4))}{COLORS['white']}")
    
    while True:
        prompt_text = f"\n{COLORS['magenta']}→ Enter format number{COLORS['white']} (e.g., {COLORS['yellow']}0{COLORS['white']} for Best, or {COLORS['yellow']}137+140{COLORS['white']} for custom): "
        selection = input(prompt_text).strip()
        
        if selection in id_map:
            if selection == '0':
                log_message("Select", "green", "Best quality format selected")
                return None
            else:
                log_message("Select", "green", f"Format {id_map[selection]} selected")
                return id_map[selection]

        if re.match(r'^[\d,+-]+$', selection):
            log_message("Select", "green", f"Custom format '{selection}' selected")
            return selection
        
        log_message("Invalid", "yellow", "Please enter a valid number, format ID, or combined format (e.g., '137+140')")



def main():
    """
    Main function to run the CUI.
    """
    while True:
        render_ascii()
        
        width = get_terminal_width()
        line = '─' * (width - 2)
        inner_text = "EASY-DLP Media Downloader | Made with LOVE | Created by gahoo.dev"
        # 内側の幅は width - 2 (左右の | の分)
        inner_width = width - 2
        text_len = len(inner_text)
        total_padding = inner_width - text_len
        left_pad = total_padding // 2
        right_pad = total_padding - left_pad
        print()
        print(f"{COLORS['light_blue']} {COLORS['cyan']}{' ' * left_pad}{inner_text}{' ' * right_pad}{COLORS['light_blue']}{COLORS['white']}")
        
        # Menu frame
        print(f"\n{COLORS['light_blue']}╭{line}╮{COLORS['white']}")
        menu_items = [
            f"{COLORS['cyan']}«{COLORS['white']}01{COLORS['cyan']}»{COLORS['white']} MP4 Download",
            f"{COLORS['cyan']}«{COLORS['white']}02{COLORS['cyan']}»{COLORS['white']} MP3 Download",
            f"{COLORS['cyan']}«{COLORS['white']}03{COLORS['cyan']}»{COLORS['white']} Settings",
            f"{COLORS['cyan']}«{COLORS['white']}04{COLORS['cyan']}»{COLORS['white']} Exit"
        ]
        menu_text = "   ".join(menu_items)
        menu_len = len("«01» MP4 Download   «02» MP3 Download   «03» Settings   «04» Exit")
        menu_padding = inner_width - menu_len
        menu_left_pad = menu_padding // 2
        menu_right_pad = menu_padding - menu_left_pad
        print(f"{COLORS['light_blue']}│{COLORS['white']}{' ' * menu_left_pad}{menu_text}{' ' * menu_right_pad}{COLORS['light_blue']}│{COLORS['white']}")
        print(f"{COLORS['light_blue']}╰{line}╯{COLORS['white']}")
        
        # Credits info
        credits_raw = "«~» Credits"
        left_pad = max(0, (inner_width - len(credits_raw)) // 2)
        right_pad = max(0, inner_width - len(credits_raw) - left_pad)
        print(f"\n{COLORS['light_blue']}│{COLORS['white']}{' ' * left_pad}{COLORS['light_blue']}«~»{COLORS['cyan']} Credits{COLORS['white']}{' ' * right_pad}{COLORS['light_blue']}│{COLORS['white']}")
        prompt_text = f"\n{COLORS['arrow']}-> "
        menu_choice = input(prompt_text).strip()
        
        if menu_choice == '1' or menu_choice == '01':
            download_media(width, 'mp4')
        elif menu_choice == '2' or menu_choice == '02':
            download_media(width, 'mp3')
        elif menu_choice == '3' or menu_choice == '03':
            show_settings()
        elif menu_choice == '4' or menu_choice == '04':
            log_message("Exit", "green", "Thank you for using EASY-DLP!")
            break
        elif menu_choice.lower() == '~':
            show_credits()
        else:
            log_message()

def download_media(width, media_type):
    """Handle media download based on type."""
    # 1. Get URL
    while True:
        prompt_text = f"\n{COLORS['magenta']}[1/3]{COLORS['white']} Enter the URL: "
        url = input(prompt_text).strip()
        if url:
            log_message("Input", "green", "URL received")
            break
        log_message("Error", "red", "URL cannot be empty")
    
    # 2. Get save directory
    while True:
        default_display = DEFAULT_SAVE_DIR if DEFAULT_SAVE_DIR != "." else "current directory"
        prompt_text = f"\n{COLORS['magenta']}[2/3]{COLORS['white']} Enter save directory (default: {default_display}): "
        save_dir = input(prompt_text).strip()
        if not save_dir:
            save_dir = DEFAULT_SAVE_DIR
            log_message("Input", "green", f"Using default: {default_display}")
            break
        if os.path.isdir(save_dir):
            log_message("Input", "green", f"Directory: {save_dir}")
            break
        else:
            # Try to create the directory
            try:
                os.makedirs(save_dir, exist_ok=True)
                log_message("Input", "green", f"Created directory: {save_dir}")
                break
            except Exception as e:
                log_message("Error", "red", f"Cannot create directory: {str(e)[:50]}")

    # 3. Get available formats
    formats = get_formats(url)
    if not formats:
        return

    # 4. Select format (skip for MP3)
    if media_type == 'mp4':
        format_code = select_format(formats, media_type='mp4')
    else:
        format_code = None
    
    # 5. Build command and execute
    command = [YTDLP_CMD, url, "-o", os.path.join(save_dir, "%(title)s.%(ext)s")]
    
    if format_code:
        command.extend(["-f", format_code])
    
    # Convert to MP3 if selected
    if media_type == 'mp3':
        log_message("Option", "blue", "MP3 format selected, converting audio...")
        command.extend(["--extract-audio", "--audio-format", "mp3"])
    
    # Add metadata and thumbnail
    command.extend(["--add-metadata", "--embed-thumbnail"])
    
    # 5. Display and Execute
    line = '─' * (width - 2)
    print(f"\n{COLORS['light_blue']}╭{line}╮{COLORS['white']}")
    print(f"{COLORS['cyan']}{'Command Preview'.center(width-2)}{COLORS['white']}")
    print(f"{COLORS['light_blue']}├{line}┤{COLORS['white']}")
    for i, arg in enumerate(command):
        print(f"{COLORS['light_blue']}│ {COLORS['yellow']}{arg}{COLORS['white']}")
    print(f"{COLORS['light_blue']}╰{line}╯{COLORS['white']}")
    
    prompt_text = f"\n{COLORS['magenta']}[3/3]{COLORS['white']} Execute download? {COLORS['yellow']}(y/n){COLORS['white']}: "
    confirm = input(prompt_text).strip().lower()
    
    if confirm == 'y':
        print(f"\n{COLORS['green']}{'▶ Starting Download'.center(width)}{COLORS['white']}\n")
        try:
            subprocess.run(command)
            log_message("Complete", "green", "Download finished successfully")
        except Exception as e:
            log_message("Failed", "red", f"Download failed: {str(e)[:50]}")
    else:
        log_message("Cancelled", "yellow", "Download was not executed")
    
    input(f"\n{COLORS['magenta']}Press Enter to return to menu...{COLORS['white']}")

def show_settings():
    """Show settings menu."""
    global DEFAULT_SAVE_DIR
    
    while True:
        clear_screen()
        width = get_terminal_width()
        line = '─' * (width - 2)
        
        print(f"\n{COLORS['light_blue']}╭{line}╮{COLORS['white']}")
        print(f"{COLORS['cyan']}{'Settings'.center(width-2)}{COLORS['white']}")
        print(f"{COLORS['light_blue']}├{line}┤{COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['cyan']}«1» Default Save Directory{COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['cyan']}    Current: {DEFAULT_SAVE_DIR}{COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['cyan']}yt-dlp: installed and configured{COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['cyan']}Terminal Width: {width} columns{COLORS['white']}")
        print(f"{COLORS['light_blue']}│ {COLORS['cyan']}Version: 1.0{COLORS['white']}")
        print(f"{COLORS['light_blue']}╰{line}╯{COLORS['white']}")
        
        prompt_text = f"\n{COLORS['magenta']}Select option {COLORS['white']}(1/back): "
        choice = input(prompt_text).strip().lower()
        
        if choice == '1':
            # Change default save directory
            while True:
                prompt_text = f"\n{COLORS['magenta']}Enter new default save directory: "
                new_dir = input(prompt_text).strip()
                if not new_dir:
                    log_message("Cancel", "yellow", "No changes made")
                    break
                if os.path.isdir(new_dir):
                    DEFAULT_SAVE_DIR = new_dir
                    log_message("Success", "green", f"Default directory set to: {new_dir}")
                    break
                else:
                    try:
                        os.makedirs(new_dir, exist_ok=True)
                        DEFAULT_SAVE_DIR = new_dir
                        log_message("Success", "green", f"Created and set default directory: {new_dir}")
                        break
                    except Exception as e:
                        log_message("Error", "red", f"Cannot create directory: {str(e)[:50]}")
            input(f"\n{COLORS['magenta']}Press Enter to continue...{COLORS['white']}")
        else:
            # Return to main menu
            break

def show_credits():
    """Show credits information."""
    clear_screen()
    width = get_terminal_width()
    line = '─' * (width - 2)
    
    print(f"\n{COLORS['light_blue']}╭{line}╮{COLORS['white']}")
    print(f"{COLORS['cyan']}{'Credits'.center(width-2)}{COLORS['white']}")
    print(f"{COLORS['light_blue']}├{line}┤{COLORS['white']}")
    print(f"{COLORS['light_blue']}│ {COLORS['cyan']}Developer: gahoo.dev{COLORS['white']}")
    print(f"{COLORS['light_blue']}│ {COLORS['cyan']}Website: https://gahoodev.gitlab.io/home{COLORS['white']}")
    print(f"{COLORS['light_blue']}│ {COLORS['white']}")
    print(f"{COLORS['light_blue']}│ {COLORS['cyan']}Powered by: yt-dlp{COLORS['white']}")
    print(f"{COLORS['light_blue']}╰{line}╯{COLORS['white']}")
    
    input(f"\n{COLORS['magenta']}Press Enter to return to menu...{COLORS['white']}")

if __name__ == "__main__":
    main()